const Authors = () => {
  return(
    <div className="main-body">
      Authorsasdasd
    </div>
  )
}

export default Authors