import "./titleOfPage.css"

const TitleOfPage = () => {
  return(
    <>
      <h1 className="page-title">PODCAST</h1>
    </>
  )
}

export default TitleOfPage