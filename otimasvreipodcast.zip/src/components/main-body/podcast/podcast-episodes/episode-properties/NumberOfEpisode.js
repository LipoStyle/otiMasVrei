const numberOfEpisode = (no) => {
  return(
    <p className="number-of-episode">{no.no}</p>
  )
}

export default numberOfEpisode