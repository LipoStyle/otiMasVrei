const DateRealesedOfEpisode = ({date}) => {
  return(
    <p className="date-realesed-of-episode"><em>DATE </em>{date}</p>
  )
}

export default DateRealesedOfEpisode