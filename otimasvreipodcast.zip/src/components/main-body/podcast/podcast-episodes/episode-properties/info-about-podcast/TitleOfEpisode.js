const TitleOfEpisode = ({title}) => {
  return(
    <div className="title-of-episode">{title}</div>
  )
}

export default TitleOfEpisode