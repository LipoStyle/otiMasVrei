const DurationOfEpisode = ({duration}) => {
  return(
    <p className="duration-of-episode">{duration}</p>
  )
}

export default DurationOfEpisode