const LinkToListenEpisode = ({link}) => {
  return(
    <p className="link-to-listen-episode">Listen</p>
  )
}

export default LinkToListenEpisode