const ImageOfEpisode = (url) => {
  return(
    <div className="image-of-episode">
      <img src={url.url} alt="image-of-the-episode" />
    </div>
  )
}

export default ImageOfEpisode 