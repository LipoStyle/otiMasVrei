const Home = () => {
  return(
    <div className="main-body">
      Hoasdaa234234me
    </div>
  )
}

export default Home