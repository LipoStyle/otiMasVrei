const Logo = () => {
  return(
    <div className="header-title">
      <h1>OtiMasVrei</h1>
    </div>
  )
}

export default Logo