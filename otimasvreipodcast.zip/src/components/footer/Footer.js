import './footerStylesheet.css'

const Footer = () => {
  return(
    <div className="footer">
      asdda
    </div>
  )
}

export default Footer